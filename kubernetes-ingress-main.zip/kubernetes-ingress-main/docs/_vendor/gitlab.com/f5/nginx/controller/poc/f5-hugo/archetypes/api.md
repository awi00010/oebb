---
title: "API Reference v<version>"
description: "Represents the state of NGINX Controller's API for v<version>"
date: 2019-11-15T13:21:02-07:00
weight: 10
draft: false
toc: false
tags: ["api"]
categories: []
doctypes: ["reference"]
menu: "api"
version: ["<version>"]
# Create a new entry in the Jira DOCS Catalog and add the ticket ID (DOCS-<number>) below
docs: "DOCS-000"
---

{{< openapi spec="/specs/release-<version>/openapi.yaml" >}}
