---
title: Installation
description: 
weight: 1300
menu:
  docs:
    parent: NGINX Ingress Controller
---
