---
title: Intro
description: 
weight: 1200
menu:
  docs:
    parent: NGINX Ingress Controller
---
