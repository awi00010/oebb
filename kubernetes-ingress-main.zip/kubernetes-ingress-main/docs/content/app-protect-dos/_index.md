---
title: Using with NGINX App Protect DoS
description: Learn how to use NGINX Ingress Controller for Kubernetes with NGINX App Protect DoS.
weight: 1600
menu:
  docs:
    parent: NGINX Ingress Controller
---
